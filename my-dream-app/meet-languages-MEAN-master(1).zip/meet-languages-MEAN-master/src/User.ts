export class User {
  id: number;
  name: string;
  email: string;
  lastName: string;
  nat_lang: string;
  lang_learn: string[];
  skype: string;
  description: string;
  messages: number;
  notifications: number;
}
  